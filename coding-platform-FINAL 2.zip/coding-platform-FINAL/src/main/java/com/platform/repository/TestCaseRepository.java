package com.platform.repository;

import com.platform.entity.TestCase;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TestCaseRepository extends JpaRepository<TestCase, Long> {
    List<TestCase> findByProblem_ProblemId(Long problemId);
    List<TestCase> findByProblem_ProblemIdAndIsSampleTrue(Long problemId);
}
