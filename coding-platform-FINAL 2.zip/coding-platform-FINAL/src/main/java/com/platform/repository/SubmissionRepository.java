package com.platform.repository;

import com.platform.entity.Submission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface SubmissionRepository extends JpaRepository<Submission, Long> {
    List<Submission> findByUser_UserIdOrderBySubmittedAtDesc(Long userId);
    List<Submission> findByProblem_ProblemIdOrderBySubmittedAtDesc(Long problemId);
    long countByUser_UserIdAndProblem_ProblemIdAndSubmittedAtAfter(
            Long userId, Long problemId, LocalDateTime after);
}
