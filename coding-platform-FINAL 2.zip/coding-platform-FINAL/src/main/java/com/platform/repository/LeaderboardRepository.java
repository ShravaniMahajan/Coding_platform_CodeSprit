package com.platform.repository;

import com.platform.entity.Leaderboard;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LeaderboardRepository extends JpaRepository<Leaderboard, Long> {
    Optional<Leaderboard> findByUser_UserId(Long userId);
    List<Leaderboard> findAllByOrderByTotalScoreDesc();
}
