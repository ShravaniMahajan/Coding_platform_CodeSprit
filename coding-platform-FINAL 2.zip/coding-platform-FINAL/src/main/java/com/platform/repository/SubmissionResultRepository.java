package com.platform.repository;

import com.platform.entity.SubmissionResult;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SubmissionResultRepository extends JpaRepository<SubmissionResult, Long> {
    Optional<SubmissionResult> findBySubmission_SubmissionId(Long submissionId);
}
