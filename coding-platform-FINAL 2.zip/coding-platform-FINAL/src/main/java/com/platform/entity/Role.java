package com.platform.entity;

public enum Role {
    ADMIN,
    USER
}
