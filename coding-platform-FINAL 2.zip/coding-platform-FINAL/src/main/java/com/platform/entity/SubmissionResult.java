package com.platform.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "submission_results")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SubmissionResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "result_id")
    private Long resultId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "submission_id", nullable = false, unique = true)
    private Submission submission;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    @Builder.Default
    private SubmissionStatus status = SubmissionStatus.PENDING;

    @Column(name = "passed_testcases", nullable = false)
    @Builder.Default
    private Integer passedTestcases = 0;

    @Column(name = "total_testcases", nullable = false)
    @Builder.Default
    private Integer totalTestcases = 0;

    @Column(name = "execution_time_ms", precision = 10, scale = 2, nullable = false)
    @Builder.Default
    private BigDecimal executionTimeMs = BigDecimal.ZERO;

    @Column(name = "memory_used_mb", precision = 10, scale = 2, nullable = false)
    @Builder.Default
    private BigDecimal memoryUsedMb = BigDecimal.ZERO;

    @Column(nullable = false)
    @Builder.Default
    private Integer score = 0;

    @Column(name = "evaluated_at")
    private LocalDateTime evaluatedAt;
}
