package com.platform.entity;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD
}
