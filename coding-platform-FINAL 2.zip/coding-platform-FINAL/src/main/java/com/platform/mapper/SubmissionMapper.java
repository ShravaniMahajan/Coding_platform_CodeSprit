package com.platform.mapper;

import com.platform.dto.submission.SubmissionResponse;
import com.platform.entity.Submission;
import com.platform.entity.SubmissionResult;
import com.platform.entity.SubmissionStatus;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class SubmissionMapper {

    public SubmissionResponse toResponse(Submission submission) {
        SubmissionResult result = submission.getResult();

        return SubmissionResponse.builder()
                .submissionId(submission.getSubmissionId())
                .problemId(submission.getProblem().getProblemId())
                .problemTitle(submission.getProblem().getTitle())
                .language(submission.getLanguage())
                .submittedAt(submission.getSubmittedAt())
                .status(result != null ? result.getStatus() : SubmissionStatus.PENDING)
                .passedTestcases(result != null ? result.getPassedTestcases() : 0)
                .totalTestcases(result != null ? result.getTotalTestcases() : 0)
                .executionTimeMs(result != null ? result.getExecutionTimeMs() : BigDecimal.ZERO)
                .memoryUsedMb(result != null ? result.getMemoryUsedMb() : BigDecimal.ZERO)
                .score(result != null ? result.getScore() : 0)
                .build();
    }
}
