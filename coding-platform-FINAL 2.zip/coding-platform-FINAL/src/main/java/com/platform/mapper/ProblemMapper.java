package com.platform.mapper;

import com.platform.dto.problem.ProblemResponse;
import com.platform.dto.problem.TestCaseResponse;
import com.platform.entity.Problem;
import com.platform.entity.TestCase;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ProblemMapper {

    public ProblemResponse toResponse(Problem problem, boolean includeAllTestCases) {
        List<TestCaseResponse> testCases = problem.getTestCases().stream()
                .filter(tc -> includeAllTestCases || Boolean.TRUE.equals(tc.getIsSample()))
                .map(this::toTestCaseResponse)
                .toList();

        return ProblemResponse.builder()
                .problemId(problem.getProblemId())
                .title(problem.getTitle())
                .description(problem.getDescription())
                .difficulty(problem.getDifficulty())
                .category(problem.getCategory())
                .topicTags(problem.getTopicTags())
                .inputFormat(problem.getInputFormat())
                .outputFormat(problem.getOutputFormat())
                .constraints(problem.getConstraints())
                .sampleInput(problem.getSampleInput())
                .sampleOutput(problem.getSampleOutput())
                .starterCode(problem.getStarterCode())
                .timeLimitMs(problem.getTimeLimitMs())
                .memoryLimitMb(problem.getMemoryLimitMb())
                .marks(problem.getMarks())
                .createdAt(problem.getCreatedAt())
                .visibleTestCases(testCases)
                .build();
    }

    public TestCaseResponse toTestCaseResponse(TestCase testCase) {
        return TestCaseResponse.builder()
                .testcaseId(testCase.getTestcaseId())
                .input(testCase.getInput())
                .expectedOutput(testCase.getExpectedOutput())
                .isSample(testCase.getIsSample())
                .build();
    }
}
