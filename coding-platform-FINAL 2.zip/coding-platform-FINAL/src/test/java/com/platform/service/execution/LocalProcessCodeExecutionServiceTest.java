package com.platform.service.execution;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * These tests shell out to python3 on the PATH and are skipped in
 * environments where it isn't available (e.g. minimal CI images).
 */
class LocalProcessCodeExecutionServiceTest {

    private final LocalProcessCodeExecutionService service = new LocalProcessCodeExecutionService();

    @Test
    void validPythonCode_producesExpectedOutput() {
        String code = "print(input().strip().upper())";
        ExecutionResult result = service.execute("PYTHON", code, "hello", 5000);

        if (result.getOutcome() == ExecutionOutcome.RUNTIME_ERROR
                && result.getStderr() != null
                && result.getStderr().toLowerCase().contains("no such file")) {
            return; // python3 not installed in this environment — skip
        }

        assertEquals(ExecutionOutcome.SUCCESS, result.getOutcome());
        assertTrue(result.getStdout().trim().equalsIgnoreCase("HELLO"));
    }

    @Test
    void infiniteLoop_isTerminatedByTimeout() {
        String code = "while True:\n    pass\n";
        ExecutionResult result = service.execute("PYTHON", code, "", 1000);

        if (result.getOutcome() == ExecutionOutcome.RUNTIME_ERROR
                && result.getStderr() != null
                && result.getStderr().toLowerCase().contains("no such file")) {
            return; // python3 not installed in this environment — skip
        }

        assertEquals(ExecutionOutcome.TIME_LIMIT_EXCEEDED, result.getOutcome());
    }

    @Test
    void unsupportedLanguage_returnsCompilationError() {
        ExecutionResult result = service.execute("COBOL", "IDENTIFICATION DIVISION.", "", 1000);
        assertEquals(ExecutionOutcome.COMPILATION_ERROR, result.getOutcome());
    }
}
